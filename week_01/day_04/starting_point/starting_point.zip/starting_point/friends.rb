def get_name(person)
  return person[:name]
end
